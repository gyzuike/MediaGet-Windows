process.on('message',message=>{if(message==='mediaget-shutdown')process.exit(0);});
process.on('disconnect',()=>process.exit(0));
require('./cookie-fetch.cjs').installCookieFetch();
require(require('node:path').join(process.cwd(),'server.js'));
